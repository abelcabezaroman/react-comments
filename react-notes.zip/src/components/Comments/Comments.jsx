import { useForm } from "react-hook-form";

export default function Comments() {
    const { handleSubmit, register } = useForm()

    return <div>

    </div>
}