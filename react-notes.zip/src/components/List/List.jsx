import { useState } from "react"
import Comments from "../Comments/Comments";

export default function List({ data }) {
    const [list, setList] = useState(data);

    const remove = (index) => {
        const copyList = [...list];
        copyList.splice(index, 1)
        setList(copyList)
    }

    const addOredit = (index) => {
        const copyList = [...list];
        const name = prompt("Escribe un nombre")
        const qty = prompt("Escribe una cantidad")

        if(name && name !== "" && qty && qty !== ""){
            copyList[index] = {name, qty, comments : []};
            setList(copyList)
        } else{
            alert("Mete argo pisha")
        }
    }

    return <div>
        {list.map((item, index) => <div key={item.name}>
            <h2>{item.name}</h2>
            <h2>cantidad: {item.qty}</h2>
            <button onClick={() => addOredit(index)}>Edit</button>
            <button onClick={() => remove(index)}>X</button>
            {/* <button onClick={() => addComment(index)}>Comment</button> */}
        </div>)}
        <button onClick={() => addOredit(list.length)}>Add new</button>

        <div><Comments/></div>
    </div>
}