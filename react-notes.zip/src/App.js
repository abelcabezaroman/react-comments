import './App.css';
import List from './components/List/List';

const defaultList = [
  {
    name: "Cuaderno",
    qty: 2,
    comments: []
  }, {
    name: "Cuadernillo",
    qty: 2,
    comments: [
      { text: "asdasdads", user: "red" },
      { text: "asdasdads", user: "green" },
      { text: "asdasdads", user: "red" },
      { text: "asdasdads", user: "red" },
      { text: "asdasdads", user: "green" },
    ]
  }
]

function App() {
  return (
    <div className="App">
      <div className="App-header">
        <List data={defaultList} />
      </div>
    </div>
  );
}

export default App;
